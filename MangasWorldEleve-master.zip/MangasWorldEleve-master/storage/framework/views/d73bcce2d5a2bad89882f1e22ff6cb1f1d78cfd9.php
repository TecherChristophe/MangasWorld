
<table class = "table table-bordered table-striped" >

    <thead>
        <th> Id </th>
        <th> Prix </th>
        <th> Titre </th>
        <th> Genre </th>
    </thead>
<?php $__currentLoopData = $lesMangas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td> <?php echo e($manga -> getIdManga()); ?> </td>
            <td> <?php echo e($manga -> getPrix()); ?> </td>
            <td> <?php echo e($manga -> getTitre()); ?> </td>
            <td> <?php echo e($manga -> getGenre()); ?> </td>

        </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php /**PATH /home/tom/websites/MangasWorldEleve-master/resources/views/listeMangas.blade.php ENDPATH**/ ?>