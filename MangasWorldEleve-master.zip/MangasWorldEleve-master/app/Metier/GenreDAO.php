<?php


namespace App\Metier;

use DB;

class GenreDAO extends DAO
{

    public function getGenre($id_genre)
    {
        $genre = array();
        $Lesgenres = DB::table('genre')->where('id_genre','=', $id_genre)->get();
        foreach($Lesgenres as $legenre)
        {
            $genre = $this->creerObjetMetier($legenre);
        }

        return $genre;
    }

    protected function creerObjetMetier(\stdClass $objet)
    {
        $genre = new Genre();
        $genre->setIdGenre($objet->id_genre);
        $genre->setLibelleGenre($objet->lib_genre);
        return $genre;
    }

}