<?php

namespace App\Metier;

use Illuminate\Database\ELoquent\Model;

abstract class DAO extends Model{

    protected abstract function creerObjetMetier(\stdClass $objet);
}