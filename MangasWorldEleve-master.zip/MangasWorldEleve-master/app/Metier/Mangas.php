<?php

namespace App\Metier;

use DB;
use Illuminate\Database\Eloquent\Model;

class Mangas extends Model
{
    public function getLesMangas()
    {
        $lesMangas = DB::table('manga')->get();
        return $lesMangas;
    }
}
