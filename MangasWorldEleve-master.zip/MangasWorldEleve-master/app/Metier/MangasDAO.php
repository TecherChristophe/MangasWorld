<?php


namespace App\Metier;

use DB;

class MangasDAO extends DAO
{
    public function getLesMangas()
    {
        $mangas = DB::table('manga')->get();
        $lesMangas = array();
        foreach($mangas as $lemanga)
        {
            $idManga = $lemanga->id_manga;
            $lesMangas[$idManga]=$this->creerObjetMetier($lemanga);
        }
        return $lesMangas;
    }

    protected function creerObjetMetier(\stdClass $objet)
    {
        $leManga = new Manga();
        $leManga->setIdManga($objet->id_manga);
        $leManga->setPrix($objet->prix);
        $leManga->setTitre($objet->titre);
        //$lib_genre =DB::table('genre')->select('lib_genre')->where('id_genre','=',$objet->id_genre)->get();
        $genreDAO = new GenreDAO();
        $genre = $genreDAO->getGenre($objet->id_genre);
        $leManga->setGenre($genre->getLibelleGenre());

        return $leManga;
    }
}